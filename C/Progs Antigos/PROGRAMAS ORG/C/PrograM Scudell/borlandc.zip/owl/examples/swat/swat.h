// ObjectWindows - (C) Copyright 1992 by Borland International
//
// swat.h

#define IDM_RESET	100
#define IDM_OPTION	101
#define IDM_ABOUT	102
#define IDM_PAUSE	103
#define IDM_STOP	104

#define IDD_LIVETIMESB		101
#define IDD_POPSB		102

#define IDD_INPUTEDITBOX	109
