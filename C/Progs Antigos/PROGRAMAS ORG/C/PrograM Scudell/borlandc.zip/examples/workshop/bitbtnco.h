// (C) Copyright 1991, 1992 by Borland International

#define	ID_BUTTONSTYLE		100
#define ID_CAPTION			100
#define	ID_CONTROLID		101
#define	ID_TABSTOP			102
#define	ID_DISABLED			103
#define	ID_GROUP         	104
#define	ID_DEFAULTBUTTON	105
#define	ID_PUSHBUTTON		106
#define	BT_DISABLEBITS		100
#define	BT_DEFBITS			101
#define	BT_UNDEFBITS		102
#define	CR_DEFCURS			100
#define	CR_UNDEFCURS		101
