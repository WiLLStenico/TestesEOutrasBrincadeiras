// Borland C++ - (C) Copyright 1991, 1992 by Borland International

/*	HELLO.C -- Hello, world */

#include <stdio.h>

int main()
{
	printf("Hello, world\n");
	return 0;
}



	

