/*  memory.h

    Memory manipulation functions

    Copyright (c) 1991, 1992 by Borland International
    All Rights Reserved.
*/

#include <mem.h>
