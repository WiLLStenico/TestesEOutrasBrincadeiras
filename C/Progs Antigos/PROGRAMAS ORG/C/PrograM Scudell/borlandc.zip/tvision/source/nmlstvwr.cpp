/*------------------------------------------------------------*/
/* filename -       nmlstvwr.cpp                              */
/*                                                            */
/* defines the streamable name for class TListViewer          */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TListViewer
#include <tv.h>

const char * const near TListViewer::name = "TListViewer";

