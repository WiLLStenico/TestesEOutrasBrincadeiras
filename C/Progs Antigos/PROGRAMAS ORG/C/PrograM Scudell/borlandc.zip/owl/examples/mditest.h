// ObjectWindows - (C) Copyright 1992 by Borland International

#define CM_COUNTCHILDREN    201

#define ID_CLOSEBOX         101
