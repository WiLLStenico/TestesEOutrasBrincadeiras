// ObjectWindows - (C) Copyright 1992 by Borland International
//
// paltest.h

#define CM_ABOUT 100

