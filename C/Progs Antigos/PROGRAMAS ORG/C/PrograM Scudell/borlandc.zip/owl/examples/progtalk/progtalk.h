// ObjectWindows - (C) Copyright 1992 by Borland International

// Resource IDs

#define ID_DDEDIALOG	100
#define ID_ADDDIALOG	101
#define ID_CREATEDIALOG	102


// DDE dialog item IDs

#define ID_LISTBOX	100
#define ID_ADDITEM	101
#define ID_DELETEITEM	102
#define ID_CLEARITEMS	103
#define ID_CREATEGROUP	104
