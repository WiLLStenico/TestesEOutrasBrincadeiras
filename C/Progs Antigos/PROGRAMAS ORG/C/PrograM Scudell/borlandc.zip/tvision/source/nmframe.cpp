/*------------------------------------------------------------*/
/* filename -       nmframe.cpp                               */
/*                                                            */
/* defines the streamable name for class TFrame               */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TFrame
#include <tv.h>

const char * const near TFrame::name = "TFrame";

