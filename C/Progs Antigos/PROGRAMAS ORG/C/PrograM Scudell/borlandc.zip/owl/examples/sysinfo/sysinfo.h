// ObjectWindows - (C) Copyright 1992 by Borland International

#define ID_ENHANCED	0
#define ID_STANDARD	1
#define ID_REAL		2
#define ID_CPU8086	3
#define ID_CPU80186	4
#define ID_CPU80286	5
#define ID_CPU80386	6
#define ID_CPU80486	7
#define ID_YES		8
#define ID_NO		9
#define ID_UNKNOWN	10

#define ID_INSTANCENUMBER	200
#define ID_WINDOWSVERSION	201
#define ID_OPERATIONMODE 	202
#define ID_CPUTYPE		203
#define ID_COPROCESSOR		204
#define ID_GLOBAL	 	205
#define ID_VERSIONDOS		206
