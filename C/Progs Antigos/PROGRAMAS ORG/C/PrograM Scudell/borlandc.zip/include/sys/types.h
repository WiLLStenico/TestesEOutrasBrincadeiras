/*  types.h

    Types for dealing with time.

    Copyright (c) 1987, 1992 by Borland International
    All Rights Reserved.
*/

#ifndef  _TIME_T
#define  _TIME_T
typedef long time_t;
#endif
