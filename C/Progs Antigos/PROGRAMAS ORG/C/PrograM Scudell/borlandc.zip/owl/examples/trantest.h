// ObjectWindows - (C) Copyright 1992 by Borland International

#define ID_MENU 100
#define CM_TEST 101

#define ID_DIALOG 200
#define ID_MRBUTTON 201
#define ID_MSBUTTON 202
#define ID_DRBUTTON 203
#define ID_NAMEEDIT 204
#define ID_ADDR1EDIT 205
#define ID_ADDR2EDIT 206
#define ID_CITYSTEDIT 207
#define ID_COUNTRYEDIT 208

