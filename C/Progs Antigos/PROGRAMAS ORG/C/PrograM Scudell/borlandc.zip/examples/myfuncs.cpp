char ss[] = "The restaurant at the end of ";

char *GetString(void)
{
	return ss;
}