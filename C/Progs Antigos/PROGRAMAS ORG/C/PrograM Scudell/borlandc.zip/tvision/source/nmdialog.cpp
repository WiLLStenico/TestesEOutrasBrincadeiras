/*------------------------------------------------------------*/
/* filename -       nmdialog.cpp                              */
/*                                                            */
/* defines the streamable name for class TDialog              */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TDialog
#include <tv.h>

const char * const near TDialog::name = "TDialog";

