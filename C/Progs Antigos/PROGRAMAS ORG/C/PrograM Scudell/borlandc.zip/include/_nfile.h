/*  _nfile.h

    Maximum number of open files

    Copyright (c) 1991, 1992 by Borland International
    All Rights Reserved.
*/

#ifndef ___NFILE_H
#define ___NFILE_H

#define _NFILE_ 20

#endif
