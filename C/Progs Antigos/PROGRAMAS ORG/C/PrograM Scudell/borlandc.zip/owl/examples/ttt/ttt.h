// ObjectWindows - (C) Copyright 1992 by Borland International

#define CM_GAMENEW          211
#define CM_GAMEOPTIONS      212
#define CM_ABOUT            999
#define IDSTATIC            502
#define IDYOU               102
#define IDME                103
#define IDYOUMEGROUP        104
#define IDXOGROUP           105
#define IDO                 106
#define IDX                 107
