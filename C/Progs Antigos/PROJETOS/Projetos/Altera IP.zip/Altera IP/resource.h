#include <windows.h>

// ID of Main Dialog
#define DLG_MAIN 101

// ID of Button Controls
#define IDC_BTN_1 1001
#define IDC_BTN_2 1002
#define IDC_BTN_3 1003
#define IDC_BTN_4 1004
#define IDC_BTN_5 1005
#define IDC_BTN_6 1006
#define IDC_BTN_7 1007
#define IDC_BTN_8 1008
#define IDC_BTN_9 1009
#define IDC_BTN_0 1000
#define IDC_BTN_PONTO 1010
#define IDC_BTN_ALTERA 1012

#define IDC_BTN_QUIT 1013
