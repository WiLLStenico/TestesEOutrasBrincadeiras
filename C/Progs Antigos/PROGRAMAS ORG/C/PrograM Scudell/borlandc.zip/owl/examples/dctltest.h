// ObjectWindows - (C) Copyright 1992 by Borland International

#define CM_TEST      201

#define ID_BUTTON1   101
#define ID_BUTTON2   102

