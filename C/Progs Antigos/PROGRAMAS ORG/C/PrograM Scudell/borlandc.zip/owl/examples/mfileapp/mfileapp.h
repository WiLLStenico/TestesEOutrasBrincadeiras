// ObjectWindows - (C) Copyright 1992 by Borland International

#define CM_SAVESTATE     200
#define CM_RESTORESTATE  201
