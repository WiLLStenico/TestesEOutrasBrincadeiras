// ObjectWindows - (C) Copyright 1992 by Borland International

extern "C"
{
  BOOL far CreateDLLWindow(HWND ParentHWnd);
}

