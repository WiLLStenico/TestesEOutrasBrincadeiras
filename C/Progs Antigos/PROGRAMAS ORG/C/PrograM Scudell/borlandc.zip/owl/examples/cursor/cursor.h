// ObjectWindows - (C) Copyright 1992 by Borland International

#define	IDD_SX	11
#define	IDD_SY  12

#define	IDD_PX  13
#define	IDD_PY	14
#define	IDD_HP	15

#define	IDD_WX	16
#define	IDD_WY  17
#define	IDD_HW	18

#define	IDD_HF		19
#define	IDD_TOP 	20
#define	IDD_LEFT        21
#define	IDD_BOTTOM	22
#define	IDD_RIGHT       23
