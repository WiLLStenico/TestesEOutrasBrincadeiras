/*------------------------------------------------------------*/
/* filename -       nmmnubox.cpp                              */
/*                                                            */
/* defines the streamable name for class TMenuBox             */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TMenuBox
#include <tv.h>

const char * const near TMenuBox::name = "TMenuBox";

