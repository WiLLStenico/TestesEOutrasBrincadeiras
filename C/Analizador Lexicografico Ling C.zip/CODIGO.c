#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include <conio.h>



int main(){
    FILE *fp;           /* apontador para o ficheiro */
    char caracter;
   //char palavra[100];


if(!(fp = fopen("c:/entrada.txt", "r"))){
        printf("\n\tErro na Abertura do Arquivo\n Verifique se existe um arquivo com o nome \"entrada.txt\" no diretorio C:");
        getch();
        exit(1);
    }

//caracter[1]='\0';
    /* Contar os caracteres do ficheiro */
    while ((caracter=fgetc(fp)) != EOF){

        if(caracter=='i'){
            putchar(caracter);
            caracter=fgetc(fp);
            if(caracter=='n'){
                putchar(caracter);
                caracter=fgetc(fp);
                if(caracter=='t'){
                    putchar(caracter);
                    caracter=fgetc(fp);
                    if((caracter==' ')||(caracter=='\n')){
                    puts(" -Palavra Reservada\n");
                    caracter=fgetc(fp);
                    while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='0')&&(caracter!='1')&&(caracter!='2')&&(caracter!='3')&&(caracter!='4')&&(caracter!='5')&&(caracter!='6')&&(caracter!='7')&&(caracter!='8')&&(caracter!='9')){
                        putchar(caracter);
                        caracter=fgetc(fp);
                    }
                    if((caracter=='0')||(caracter=='1')||(caracter=='2')||(caracter=='3')||(caracter=='4')||(caracter=='5')||(caracter=='6')||(caracter=='7')||(caracter=='8')||(caracter=='9')){
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                    }else if((caracter==' ')||(caracter==EOF)||(caracter==';')){
                        puts(" -Identificador Valido\n");
                        if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                        }

                    }
                    }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }




                    ////////////////

                }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
            }else if(caracter=='f'){
                putchar(caracter);
                caracter=fgetc(fp);
                if((caracter==' ')||(caracter=='(')){
                puts(" -Identificador Valido\n");
                if(caracter=='('){
                    puts("( -Parenteses\n");
                    caracter=fgetc(fp);
                    while((caracter!=' ')&&(caracter!='<')&&(caracter!='>')&&(caracter!='=')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='0')&&(caracter!='1')&&(caracter!='2')&&(caracter!='3')&&(caracter!='4')&&(caracter!='5')&&(caracter!='6')&&(caracter!='7')&&(caracter!='8')&&(caracter!='9')){
                        putchar(caracter);
                        caracter=fgetc(fp);
                    }
                    if((caracter=='0')||(caracter=='1')||(caracter=='2')||(caracter=='3')||(caracter=='4')||(caracter=='5')||(caracter=='6')||(caracter=='7')||(caracter=='8')||(caracter=='9')){
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='<')&&(caracter!='>')&&(caracter!='=')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                    }else if((caracter==' ')||(caracter==EOF)||(caracter==';')||(caracter=='<')||(caracter=='>')||(caracter=='=')){
                        puts(" -Identificador Valido\n");

                        if((caracter=='>')||(caracter=='<')){
                        putchar(caracter);
                        caracter=fgetc(fp);
                        if(caracter=='='){
                        putchar(caracter);
                        }
                        puts(" -Operador Relacional\n");
                        }else if(caracter=='='){
                        putchar(caracter);
                        puts(" -Operador Relacional\n");
                        }


                        if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                        }

                    }
                    }


                }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
            }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }

        }else if(caracter=='c'){
                putchar(caracter);
                caracter=fgetc(fp);
                if(caracter=='h'){
                    putchar(caracter);
                    caracter=fgetc(fp);
                    if(caracter=='a'){
                        putchar(caracter);
                        caracter=fgetc(fp);
                        if(caracter=='r'){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter==' '){
                                puts(" -Palavra Reservada\n");
                                caracter=fgetc(fp);
                                while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='0')&&(caracter!='1')&&(caracter!='2')&&(caracter!='3')&&(caracter!='4')&&(caracter!='5')&&(caracter!='6')&&(caracter!='7')&&(caracter!='8')&&(caracter!='9')){
                                    putchar(caracter);
                                    caracter=fgetc(fp);
                                }
                                if((caracter=='0')||(caracter=='1')||(caracter=='2')||(caracter=='3')||(caracter=='4')||(caracter=='5')||(caracter=='6')||(caracter=='7')||(caracter=='8')||(caracter=='9')){
                                    while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')){
                                    putchar(caracter);
                                    caracter=fgetc(fp);

                                }
                                puts(" -Identificador Invalido\n");
                                if(caracter==';'){
                                putchar(caracter);
                                puts(" -Nao Reconhecido\n");
                                }

                                }else puts(" -Identificador Valido\n");
                            }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                        }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                    }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                }
        }else if(caracter=='e'){
                putchar(caracter);
                caracter=fgetc(fp);
                if(caracter=='l'){
                    putchar(caracter);
                    caracter=fgetc(fp);
                    if(caracter=='s'){
                        putchar(caracter);
                        caracter=fgetc(fp);
                        if(caracter=='e'){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if((caracter==' ')||(caracter==';')||(caracter=='\n')){
                                puts(" -Palavra Reservada\n");
                                if(caracter==';'){
                                putchar(caracter);
                                puts(" -Nao Reconhecido\n");
                                }
                                //caracter=fgetc(fp);
                            }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                        }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                    }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
                }else{
                        while((caracter!=' ')&&(caracter!=EOF)&&(caracter!=';')&&(caracter!='\n')
                        &&(caracter!='(')&&(caracter!=')')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')){
                            putchar(caracter);
                            caracter=fgetc(fp);

                        }
                        puts(" -Identificador Invalido\n");
                        if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }
                    }
        }else if(caracter=='('){
            putchar(caracter);
            puts(" -Parenteses\n");
            }else if(caracter==')'){
                putchar(caracter);
                puts(" -Parenteses\n");
                }else if((caracter=='>')||(caracter=='<')){
                    putchar(caracter);
                    caracter=fgetc(fp);
                    if(caracter=='='){
                    putchar(caracter);
                    }
                    puts(" -Operador Relacional\n");
                        }else if(caracter=='='){
                    putchar(caracter);
                    puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                                }else if((caracter=='0')||(caracter=='1')||(caracter=='2')||(caracter=='3')||(caracter=='4')||(caracter=='5')||(caracter=='6')||(caracter=='7')||(caracter=='8')||(caracter=='9')){
                                    while((caracter=='0')||(caracter=='1')||(caracter=='2')||(caracter=='3')||(caracter=='4')||(caracter=='5')||(caracter=='6')||(caracter=='7')||(caracter=='8')||(caracter=='9')){
                                    putchar(caracter);
                                    caracter=fgetc(fp);
                                    }
                                    if((caracter==' ')||(caracter=='\n')||(caracter==EOF)||(caracter==')')||(caracter=='(')||(caracter=='=')||(caracter=='<')||(caracter=='>')){
                                        puts(" -Constante\n");
                                    }else{
                                        puts(" -Identificador Invalido\n");
                                    }
                        }else if ((caracter!='\n')&&(caracter!=' ')){
                            while((caracter!=' ')&&(caracter!='\n')&&(caracter!=EOF)&&(caracter!=')')&&(caracter!='(')&&(caracter!='=')&&(caracter!='<')&&(caracter!='>')&&(caracter!=';')){
                                putchar(caracter);
                                caracter=fgetc(fp);
                                //getch();
                            }
                            puts(" -Identificador Invalido\n");
                             if(caracter=='('){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if(caracter==')'){
                            putchar(caracter);
                            puts(" -Parenteses\n");
                            }else if((caracter=='>')||(caracter=='<')){
                            putchar(caracter);
                            caracter=fgetc(fp);
                            if(caracter=='='){
                            putchar(caracter);
                            }
                            puts(" -Operador Relacional\n");
                            }else if(caracter=='='){
                            putchar(caracter);
                            puts(" -Operador Relacional\n");
                            }else if(caracter==';'){
                            putchar(caracter);
                            puts(" -Nao Reconhecido\n");
                            }


                        }



    }

    puts("INTEGRANTES:\nWiLLiaM Henrique Stenico \tRA:300070489\nGiaNNe Forti \t\t\tRA:300070510\nLeanDRo MaCieL ViTTi \t\tRA:300070537");

    getch();

}
