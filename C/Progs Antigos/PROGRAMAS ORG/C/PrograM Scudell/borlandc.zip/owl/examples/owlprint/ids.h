// ObjectWindows - (C) Copyright 1992 by Borland International

#define ID_MENU 100
#define CM_FILEPRINT 101
#define CM_FILEPRINTERSETUP 102
#define CM_FILEEXIT 103


#define PRINTERSETUP_DIALOG 1000
#define ABORTPRINT_DIALOG 1010
