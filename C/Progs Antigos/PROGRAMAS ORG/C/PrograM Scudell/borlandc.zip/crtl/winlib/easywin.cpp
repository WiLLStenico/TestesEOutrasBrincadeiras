/*------------------------------------------------------------------------
 * filename - easywin.cpp
 *
 * Easy Windows functions
 *-----------------------------------------------------------------------*/

/*
 *      C/C++ Run Time Library - Version 5.0
 *
 *      Copyright (c) 1991, 1992 by Borland International
 *      All Rights Reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <mem.h>
#include <string.h>
#include <windows.h>

// These are dummy variables that are used because this module is
//   always linked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked in.

unsigned __hInstancinked 