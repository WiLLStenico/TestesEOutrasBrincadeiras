// ObjectWindows - (C) Copyright 1992 by Borland International

extern "C"
{
  BOOL far _export GetColor(HWND ParentHandle, COLORREF _FAR & ColorBuffer);
}
