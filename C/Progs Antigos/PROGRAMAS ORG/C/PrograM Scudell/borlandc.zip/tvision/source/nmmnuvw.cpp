/*------------------------------------------------------------*/
/* filename -       nmmnuvw.cpp                               */
/*                                                            */
/* defines the streamable name for class TMenuView            */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                                                            */
/*    Turbo Vision -  Version 1.0                             */
/*                                                            */
/*                                                            */
/*    Copyright (c) 1991 by Borland International             */
/*    All Rights Reserved.                                    */
/*                                                            */
/*------------------------------------------------------------*/

#define Uses_TMenuView
#include <tv.h>

const char * const near TMenuView::name = "TMenuView";

