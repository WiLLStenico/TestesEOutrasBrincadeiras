main() {
int x = 1;
x =3;
x=40;
x=95;
aa10=9;
x = -10;
}
