// ObjectWindows - (C) Copyright 1992 by Borland International

#define CM_SENDTEXT  201
