int ToggleFlag();
int Flag;
main()
{
   ToggleFlag();
}
